# BindCraft2 Lab Viewer — R Shiny prototype

**Scope:** This is an updated version of the earlier simple R Shiny structure viewer. It adds a candidate selector, a rankings table, four score indicators, `.pdb` / `.cif` visualization support, and file downloads. It is **not** an HPC or BindCraft2 server. No actual binder design occurs.

## Files

- `app.R`: complete Shiny application. Works in two configurations.
- `data/demo_candidate_A.pdb`, `data/demo_candidate_B.pdb`: **synthetic** two-chain protein-coordinate illustrations (A = target, B = binder), not experimental or ML-generated structures.
- `data/demo_ranking.csv`: **synthetic/mock** metrics, with no scientific validity.
- `preview.html`: standalone visual mockup to open immediately without R. Its rotating diagram is illustrative, not a molecular viewer.
- `README.md`: these instructions.

## Test immediately (no R needed)

Open `preview.html` in any desktop browser. This previews the layout and interactive candidate selection, but does **not** prove your R Shiny deployment works. Use the app to test the actual r3dmol component.

## Run the actual Shiny app on the CMRI RStudio environment

1. Upload/extract the entire folder into your RStudio project. Keep the relative `data/` directory beside `app.R`.
2. In the R console, run:

   ```r
   install.packages(c("shiny", "r3dmol"))  # only if not already installed
   Sys.setenv(APP_MODE = "demo")
   shiny::runApp(".")
   ```

3. Click through `Candidate A` and `Candidate B`; rotate and zoom the viewer; download a PDB and CSV.

**Important:** Open the project directory first or use `shiny::runApp("/path/to/BindCraft2_Shiny_Lab_Demo")`. The app reads its data relative to the working directory.

### Test private lab uploads (only on a restricted approved server)

```r
Sys.setenv(APP_MODE = "lab")
shiny::runApp(".")
```

Then you can upload a `.pdb`/`.cif` and optionally a ranking `.csv`. The uploaded structure is displayed independently of the ranking table. **There is NO built-in login/authentication**. Restrict access at the hosting layer before using research data.

## Test global/public accessibility

This demo does not change the reachability of `cmri-vm-rstudio.cmh.internal`. `.internal` URLs are not public internet addresses. A public site requires external hosting and a completed publishing step.

With permission from CMRI/IT to use an external platform, one practical method is [Posit Connect Cloud](https://connect.posit.cloud/), which can deploy Shiny for R content. Start in DEMO mode, with only the bundled synthetic files. The free public hosting path is appropriate for a harmless proof-of-concept, **not** for confidential datasets or private login.

From a permitted RStudio environment:

1. Open `app.R`, run it locally first.
2. In RStudio, click **Publish** and follow the prompts to connect to Posit Connect Cloud.
3. Confirm you are publishing ONLY this demo project with bundled synthetic examples, NOT any CMRI data/credentials.
4. Once published, open the generated `https://...share.connect.posit.cloud` URL from a device **not** on the hospital Wi-Fi or VPN (e.g. a mobile phone using cellular data). This is the actual global-access test.

Command-line path if publishing buttons are unavailable:

```r
install.packages("rsconnect")
rsconnect::connectCloudUser()
rsconnect::deployApp(appDir = ".")
```

**Restriction:** If CMRI's environment blocks external publishing, you may need to publish from an IT-approved personal/isolated environment. Do not copy CMRI research materials out or bypass security policy. Free public sharing is not an access-control substitute.

Documentation: https://docs.posit.co/connect-cloud/how-to/r/shiny-r.html

## For the later lab-only deployment

Deploy the same `app.R` in `APP_MODE=lab` on an institution-approved Shiny/Posit Connect environment **behind authenticated access** (e.g. institution SSO). A URL that is difficult to guess is NOT authentication. Never turn on `lab` mode in a publicly accessible, unauthenticated deployment. The uploaded data in this prototype are only for visualization; no HPC integration exists.

## Troubleshooting

- `there is no package called 'r3dmol'`: Install `r3dmol` in the R environment used by the Shiny server.
- Blank 3D viewer: check browser WebGL and network security; some environments block required JavaScript or WebGL rendering.
- File missing: ensure both `app.R` and `data/` were deployed. The app uses relative paths.
- Public URL not reachable: this means hosting/publishing or network access failed; working inside RStudio does not automatically prove public reachability.
- The demo score numbers are **illustrative only**. Don't use them to evaluate or rank actual binders.

## Scientific context

In real BindCraft2 results, `3_Ranked/!_Ranked.csv` contains ranked design metrics and `3_Ranked/*.cif` contains predicted complexes. The current prototype has no automatic cross-file linkage or validated biological interpretation.
